mat<-matrix(AirPassengers,ncol=12,byrow = TRUE)
rownames(mat)<-c("1949","1950","1951","1952","1953","1954","1955","1956","1957","1958","1959","1960")
colnames(mat)<-c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec")
Cordinates<-which(mat == max(mat), arr.ind = TRUE)
rows = rownames(mat)[Cordinates[,1]]
cols = colnames(mat)[Cordinates[,2]]
maximum<-max(mat)
sprintf("Maximum profitable month is %s",cols)
sprintf("Maximum profitable year is %s",rows)
maximum
apply(t(mat),2,cumsum)
Cumsum <- apply(t(mat),2,cumsum)
cat("Required Year is: ",rows ,"having ",max(Cumsum,12),"passengers.")


